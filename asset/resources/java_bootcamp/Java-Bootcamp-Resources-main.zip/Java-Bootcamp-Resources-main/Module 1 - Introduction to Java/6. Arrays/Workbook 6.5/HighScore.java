public class HighScore {
    public static void main(String[] args) {
        
        int highScore = 0;
        
        // Instructions for this workbook are on Learn the Part (Workbook 6.5).

        System.out.print("Here are the scores: <score elements>");

        System.out.println("\n\nThe highest score is: " + highScore + ". Give that man a cookie!");
        
    }    

}
