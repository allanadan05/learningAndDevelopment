public class Grocer {
    public static void main(String[] args) {
        
        // Instructions for this workbook are on Learn the Part (Workbook 6.3).

        System.out.println("\nDo you sell coffee?");
        System.out.println("\nWe have that in aisle: <index>");
    
    }
}
