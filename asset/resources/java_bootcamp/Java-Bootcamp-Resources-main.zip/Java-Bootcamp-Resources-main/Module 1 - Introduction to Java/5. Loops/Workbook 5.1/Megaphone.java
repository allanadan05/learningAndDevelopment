public class Megaphone {
    public static void main(String[] args) {
        // See Learn the Part for the instructions.
    }
    
}
