package pojo;

public class CashAccount {


}
