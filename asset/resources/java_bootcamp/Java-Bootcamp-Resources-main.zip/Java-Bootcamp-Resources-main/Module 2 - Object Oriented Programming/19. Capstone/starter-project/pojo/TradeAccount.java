package pojo;

public abstract class TradeAccount {


}