package pojo;

public class MarginAccount  {


}
