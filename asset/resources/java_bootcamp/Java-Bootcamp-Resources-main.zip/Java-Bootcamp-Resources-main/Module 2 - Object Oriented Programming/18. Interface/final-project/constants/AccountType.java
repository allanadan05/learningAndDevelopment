package constants;

public enum AccountType {
    CHECKING, CREDIT;
}