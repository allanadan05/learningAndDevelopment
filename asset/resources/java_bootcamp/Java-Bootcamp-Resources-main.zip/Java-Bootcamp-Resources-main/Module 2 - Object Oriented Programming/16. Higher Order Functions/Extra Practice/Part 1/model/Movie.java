package model;

public class Movie {

}
