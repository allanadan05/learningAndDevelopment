public class Airline {
    
    Person[] people; //array that stores Person objects...


}
