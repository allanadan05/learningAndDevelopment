package constants;

public enum Position {
    
}
